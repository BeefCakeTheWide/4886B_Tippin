// /*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       VEX                                                       */
/*    Created:      Thu Sep 26 2019                                           */
/*    Description:  Competition Template                                      */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// frontLeft            motor         1               
// frontRight           motor         2               
// backLeft             motor         3               
// backRight            motor         4               
// plat2                motor         6               
// plat1                motor         5               
// solenoid             digital_out   H               
// Controller1          controller                    
// beefro               inertial      10              
// SoleMogo             motor         8               
// intake               motor         9               
// LiftPot              potV2         A               
// MogoPot              potV2         B               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "4886B_Defines.h"
#include "v5standarddefines.h"
#include "vex.h"
#include <cmath>
using namespace vex;
motor_group leftDrive(frontLeft, backLeft);
motor_group rightDrive(frontRight, backRight);
motor_group platters(plat1, plat2);

motor_group fullDrive(frontLeft, backLeft, frontRight, backRight);
// A global instance of competition
competition Competition;

///////VARIABLES T/F   ///////////////////////
bool driveSlowToggled;
bool intakeToggled;
bool buttonPressed;
bool liftUpTOG;
bool pistonToggle;
float currentHeading = 0;

int driveReversed = 1;
int dir;
int autonSelect = 0;
int autonMin = 0;
int autonMax = 10;

   

// Auton Select Functions and Routine
void AutonGUI() {
  Brain.Screen.clearScreen();
  Brain.Screen.printAt(1, 40, "Determine the correct Auton");
  Brain.Screen.printAt(1, 200, "Chosen Auton: %d", autonSelect);
  Brain.Screen.setFillColor(red);
  Brain.Screen.drawRectangle(20, 50, 100, 100);
  Brain.Screen.printAt(25, 75, "SELECT");
  Brain.Screen.setFillColor(green);
  Brain.Screen.drawRectangle(170, 50, 100, 100);
  Brain.Screen.printAt(175, 75, "CONFIRM");
  Brain.Screen.setFillColor(white);
  Brain.Screen.drawRectangle(280, -10, 10, 400);

  Brain.Screen.setFillColor(black);
  Brain.Screen.printAt(300, 50, "0 = NO AUTON");
  Brain.Screen.printAt(300, 60, "1 = L'NEUTER");
  Brain.Screen.printAt(300, 70, "2 = FAWP");
  Brain.Screen.printAt(300, 80, "3 = LAWP");
  Brain.Screen.printAt(300, 90, "4 = RAWP");
  Brain.Screen.printAt(300, 100, "5 = R'NEUTER");
}

void selectAuton() {
  bool selectingAuton = true;
  int x = Brain.Screen
              .xPosition(); // get the x position of last touch of the screen
  int y = Brain.Screen
              .yPosition(); // get the y position of last touch of the screen

  if (x >= 20 && x <= 120 && y >= 50 && y <= 150) // select button pressed
  {
    autonSelect++;
    if (autonSelect > autonMax)
      autonSelect = autonMin; // rollover

    Brain.Screen.printAt(1, 200, "Auton Selected =  %d   ", autonSelect);
  }
  if (x >= 170 && x <= 270 && y >= 50 && y <= 150) {
    selectingAuton = false; // GO button pressed
    Brain.Screen.printAt(1, 200, "Auton Selected = %d ", autonSelect);
  }
  if (!selectingAuton) {
    Brain.Screen.setFillColor(green);
    Brain.Screen.drawCircle(145, 160, 15);
  } else {
    Brain.Screen.setFillColor(red);
    Brain.Screen.drawCircle(145, 160, 15);
  }
  wait(10, msec); // slow it down
  Brain.Screen.setFillColor(black);
}
void pre_auton(void) {
  solenoid.set(false);
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();
  platters.setPosition(0, degrees);
  beefro.calibrate();
  AutonGUI();
  Brain.Screen.pressed(selectAuton);

  /*---------------------------------------------------------------------------*/
  /*                                                                           */
  /*                              Autonomous Task */
  /*                                                                           */
  /*  This task is used to control your robot during the autonomous phase of */
  /*  a VEX Competition. */
  /*                                                                           */
  /*  You must modify the code to add your own robot specific commands here. */
  /*---------------------------------------------------------------------------*/
}

///////////AUTONOMOUS FUCNTIONS///////////////////
int mogoTarg = MOGO_UP;
int fourTarg = FOUR_DOWN;
void autonomous(void) {
  solenoid.set(false);
  Brain.Screen.clearScreen();
  switch (autonSelect) {
  // NO AUTON
  case 0:
    break;

  // ONE LEFT NEUTRAL
  case 1:




    pissopen
    mogoTarg = MOGO_DOWN;
    driveStraight(48, 54,200);
    wait(250,msec);
    pissclose
    fourTarg = FOUR_HOVER;
    driveStraight(-34, 54, 200);
    pissopen
    driveTurn(-pi/3, wheelToWheelDistance, 25, 30, true);
    fourTarg = FOUR_UP;
    driveStraight(-12, 50, 50);
    AutonMogo(MOGO_HOLD, 1200);
    intake.spin(forward, 580, rpm);
    driveTurn(-pi/3-pi/4,wheelToWheelDistance/2,20,20);
    driveStraight(25,15,30);
    driveStraight(-15, 15, 30);
    driveStraight(25, 15, 30);
    driveStraight(-15, 15, 30);
    AutonMogo(MOGO_DOWN, 700);
  





/*

    solenoid.set(true);           // open the claw
    mogoTarg = MOGO_DOWN;
    driveStraight(doubletile - 2 , 54, 54); // drive 44.5 inches to Neutral
    solenoid.set(false);
    driveStraight(Nfullplushalf - 4, 54, 50);
    solenoid.set(true);
    driveTurn(-pi/3, wheelToWheelDistance, 25, 30, true);
    driveStraight(Nhalftile, 50, 50);
    mogoTarg = MOGO_HOLD;
    driveStraight(halftile, 5, 10);
    intake.spin(forward, 600, rpm);
    */
    break;

  // AWP AUTON
  case 2:
    AutonLift(FOUR_AWP, 500);
    driveStraight(16, 30, 35);
    pissopen
    driveTurn(pi, 18.3, 50, 30, true);
    mogoTarg=MOGO_DOWN;
    driveStraight(-106, 54, 100);
    AutonMogo(MOGO_HOLD, 300);
    driveStraight(30, 30, 50);
    intake.spin(forward, 600, rpm);
    driveTurn(pi + pi/6, wheelToWheelDistance/2, 50,45, true);
    driveStraight(35, 25, 50);
    driveStraight(-30, 50, 50);
   
    break;

  
  case 3:
    AutonLift(FOUR_AWP, 500);
    driveStraight(16, 30, 35);
    pissopen
    break;

  // RIGHT AUTON QIN POIGT
  case 4:
  AutonMogo(MOGO_DOWN, 1300);
  driveStraight(-15, 20, 40);
  AutonMogo(MOGO_HOLD, 600);
  fourTarg = FOUR_MID;
  driveTurn(pi, 13.2, 40, 50);
  intake.spin(forward, 600, rpm);
  driveStraight(50, 20, 30);
  //driveStraight(-20, 40, 50);
  driveTurn(2*pi, wheelToWheelDistance/2, 20, 35);
  driveStraight(70, 20, 30);
  AutonMogo(MOGO_HOVER, 3000);
  



  break;

  case 5:
  driveTurn(-pi/2, wheelToWheelDistance/2, 10, 10, true);
  break;
/////////////////////////
// CUSTER'S LAST STAND //
/////////////////////////
  case 6:
  
  AutonMogo(MOGO_DOWN, 1300);
  driveStraight(-15, 20, 40);
  AutonMogo(MOGO_HOLD, 600);
  fourTarg = FOUR290;
  intake.spin(forward, 600, rpm);
  driveStraight(37,15,30);
  driveStraight(-20, 15, 30);
  driveStraight(20, 15, 30);
  driveStraight(-20, 15, 30);
  intake.stop(coast);
  fourTarg = FOUR_DOWN;
  driveTurn(1.85, wheelToWheelDistance, 30, 50);
  pissopen
  driveStraight(55, 54, 54);
  pissclose
  wait(200, msec);
  fourTarg = FOUR_UP;
  driveTurn(2.1, wheelToWheelDistance, 30, 35);
  driveStraight(50, 54, 54);
  AutonLift(FOURPLAT,700);
  pissopen
  driveStraight(-12, 30, 35);
  fourTarg = FOUR_DOWN;
  driveTurn(2.1 - pi/2, wheelToWheelDistance/2, 20, 20);
  
  
  AutonMogo(MOGO_DOWN, 1300);
  driveStraight(30,25,30);
  driveTurn(pi, wheelToWheelDistance/2, 25, 25);
  driveStraight(34, 30, 35);
  pissclose
  AutonLift(FOUR290, 1300);
  driveTurn(pi-pi/4,wheelToWheelDistance/2,20,20);
  driveStraight(4, 25, 25);
  fourTarg = FOURPLAT;
  pissopen
  driveStraight(-4, 25, 25);
  /*
  driveTurn(pi/4, wheelToWheelDistance/2, 20, 20);
  fourTarg = FOUR_DOWN;
  AutonMogo(MOGO_DOWN,1000);
  driveStraight(-50, 30, 35);
  AutonMogo(MOGO_HOLD, 600);

*/

  break;

  case 7:
  pissopen
  driveStraight(44.5,54,54);
  pissclose
  mogoTarg = MOGO_DOWN;
  driveStraight(-24,54,54);
  driveTurn(-3*pi/4,wheelToWheelDistance, 20, 20, true);
  //AutonMogo(MOGO_DOWN, 1000);
  driveStraight(-40,50,50);
  mogoTarg = MOGO_HOVER;
  driveStraight(40,54,54);

  break;
  }
}

void xPressed() { dir *= -1; }

int lpow, rpow;

// Settings
double turnImportance = .5;

void usercontrol(void) {
  mogoTarg = MOGO_DOWN;
 

  int ringspeed = 550;
  driveSlowToggled = false;

  buttonPressed = false;
  pistonToggle = false;
  solenoid.set(true);
  while (1) {

    /// DRIVE CODE STARTS HERE ///




    double turnVal = LStickUpDown;
    double forwardVal = LStickLeftRight;

    double turnVolts = turnVal * 0.12;
    double forwardVolts = forwardVal * 0.12 * (1-(std::abs(turnVolts/12.0)) * turnImportance);

    leftDrive.spin(forward, (LStickUpDown + (LStickLeftRight)/1.5)*6, rpm);
    rightDrive.spin(forward, (LStickUpDown - (LStickLeftRight)/1.5)*6, rpm);
  
    /*
    if (driveReversed == 1) {
      lpow = LStickUpDown;
      rpow = RStickUpDown;
    } else {
      lpow = -RStickUpDown;
      rpow = -LStickUpDown;
    }

    lpow *= 6; // MULTIPLIED SPEED FOR LEFT
    rpow *= 6; // MULTIPLIED SPEED FOR RIGHT
    /// THIS IS THE DEADZONE FOR THE JOYSTICKS ///
    if (lpow > 15 && lpow < 15) {
      lpow = 0;
    }
    if (rpow > 15 && rpow < 15) {
      rpow = 0;
    }
    /// THIS REVERSES THE DRIVE ///
    if (XButton) {
      if (!buttonPressed) {
        driveReversed *= -1;
        buttonPressed = true;
      } else {
        buttonPressed = false;
      }
    }
*/
    /// RING SIDE MOGO LIFTER ///
    if (L1Button && !R1Button) {
      mogoTarg = MOGO_HOLD;
      
    } else if (L2Button && !R2Button) {
      mogoTarg = MOGO_DOWN;
    } else {
      //SoleMogo.stop(brake);
    }
    mogoPID();
    
    
    /// PLATFORM LIFT ///
    if (R1Button && !L1Button) {
      platters.spin(reverse, 200, rpm);
    } else if (R2Button && !L2Button) {
      platters.spin(forward, 200, rpm);
    } else {

      platters.stop(hold);
    }
    
    /// INTAKE AND CONTINUOUS INTAKE ///
    if (YButton) {
      intake.spin(forward, ringspeed, rpm);
    } else if (XButton) {
      intake.spin(reverse, ringspeed, rpm);
    } else {
      intake.stop(coast);
    }
    /// PNEUMATIC CONTROL ///
    if (BButton) {
      if (!pistonToggle) {
        solenoid.set(ToggleBool(solenoid.value()));
        pistonToggle = true;
      }
    } else {
      pistonToggle = false;
    }
   
    Controller1.Screen.clearScreen();
    Controller1.Screen.setCursor(1,1);
    Controller1.Screen.print(LiftPot.angle(degrees));
    //Drive(lpow, rpow);
    wait(20, msec);
  }

}

int main() {
  pre_auton();
  Competition.autonomous(autonomous);
  Competition.drivercontrol(usercontrol);
  Controller1.ButtonX.pressed(xPressed);

  while (true) {
    wait(100, msec);
  }
}


void Drive(int left, int right) {

  leftDrive.setVelocity(left, rpm);
  rightDrive.setVelocity(right, rpm);
  leftDrive.spin(forward, left, rpm);
  rightDrive.spin(forward, right, rpm);
}
bool ToggleBool(bool toggled) {
  if (toggled == true)
    return false;
  else
    return true;
}
float stopDist(float vel, float accel) { return (vel * vel / (2 * accel)); }

void driveStraight(float dist, float maxVel, float accel) {
  float vel = 0;
  float pos = 0;
  float currLeft;
  float currRight;
  float LeftPosStart = leftDrive.position(turns);
  float RightPosStart = rightDrive.position(turns);
  int tickSpeed = FiftiethSecondTick;
  int currentTimer = VexTimer;
  int ticksPerSec = (Msec_TO_sec / tickSpeed);

  if (dist > 0) {
    while (vel >= 0) {

      GyroAbsPos();
      currLeft = (leftDrive.position(turns) - LeftPosStart) *
                 LargeOmni_Circumfrence * ENC_TO_DRIVE_WHEEL;
      currRight = (rightDrive.position(turns) - RightPosStart) *
                  LargeOmni_Circumfrence *
                  ENC_TO_DRIVE_WHEEL; /// this converts the code into inches
      if (pos + stopDist(vel, accel) >= dist) {
        vel -= accel / ticksPerSec; // decell
      } else if (vel < maxVel) {
        vel += accel / ticksPerSec;
      } else {
        vel = maxVel;
      }
      pos += vel / ticksPerSec;
      Drive(DRIVE_KP * (pos - currLeft) 
                + vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL 
                - STEERING_KP * (GyroAbsPos() - currentHeading), 
            DRIVE_KP * (pos - currRight) 
                + vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL 
                + STEERING_KP * (GyroAbsPos() - currentHeading));

      mogoPID();
      fourPID();
      GraphDebuggerVars(vel, pos, currLeft);
      currentTimer += tickSpeed; // wait until tickSpeed milliseconds have
                                 // passed since last iteration of while loop
      while (VexTimer < currentTimer) {
      }
    }
  } else if (dist < 0) {
    while(vel >= 0){

      GyroAbsPos();
      currLeft = (leftDrive.position(turns) - LeftPosStart) *
                 LargeOmni_Circumfrence * ENC_TO_DRIVE_WHEEL;
      currRight = (rightDrive.position(turns) - RightPosStart) *
                  LargeOmni_Circumfrence *
                  ENC_TO_DRIVE_WHEEL; 
      if(pos - stopDist(vel, accel) <= dist) {
        vel -= accel / ticksPerSec;
      } else if(vel < maxVel) {
        vel += accel / ticksPerSec;
      } else {
        vel = maxVel;
      }
      pos -= vel/ ticksPerSec;
     Drive(DRIVE_KP * (pos - currLeft) 
                - vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL 
                - STEERING_KP * (GyroAbsPos() - currentHeading), 
            DRIVE_KP * (pos - currRight) 
                - vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL 
                + STEERING_KP * (GyroAbsPos() - currentHeading));

      mogoPID();
      fourPID();
      GraphDebuggerVars(vel, pos, currLeft);
      currentTimer += tickSpeed; // wait until tickSpeed milliseconds have
                                 // passed since last iteration of while loop
      while (VexTimer < currentTimer) {
      }

    }
  }

  Drive(0, 0);
}

int GyroRollOvers = 0, PreviousGyro = 0, CurrentGyro;
int GyroAbsPos() {
  CurrentGyro = beefro.orientation(yaw, degrees);
  if (CurrentGyro - PreviousGyro > GyroMarginOfRollOver)
    GyroRollOvers--;
  else if (CurrentGyro - PreviousGyro < -GyroMarginOfRollOver)
    GyroRollOvers++;
  PreviousGyro = CurrentGyro;

  return (CurrentGyro + GyroRollOvers * DegreesPerTurn);
}

void driveTurn(float radians, float outerRadius, float maxVel, float accel,
               bool reversed) {
  int innerRadius = outerRadius - wheelToWheelDistance;
  float radiusRatio = innerRadius / outerRadius;
  float vel = 0;
  float angleLeft;
  float pos = 0;
  float currLeft;
  float currRight;
  float LeftPosStart = leftDrive.position(turns);
  float RightPosStart = rightDrive.position(turns);
  int tickSpeed = FiftiethSecondTick;
  int currentTimer = VexTimer;
  int ticksPerSec = (Msec_TO_sec / tickSpeed);

  if (radians > GyroAbsPos() / RAD_TO_DEG) { // turning right
    while (vel >= 0) {

      angleLeft = radians - GyroAbsPos() / RAD_TO_DEG;
      currLeft = (leftDrive.position(turns) - LeftPosStart) *
                 LargeOmni_Circumfrence * ENC_TO_DRIVE_WHEEL;
      currRight = (rightDrive.position(turns) - RightPosStart) *
                  LargeOmni_Circumfrence *
                  ENC_TO_DRIVE_WHEEL; /// this converts the code into inches
      if (stopDist(vel, accel) >= angleLeft * outerRadius) {
        vel -= accel / ticksPerSec; // decell
      } else if (vel < maxVel) {
        vel += accel / ticksPerSec;
      } else {
        vel = maxVel;
      }
      pos += vel / ticksPerSec;

      if (GyroAbsPos() / RAD_TO_DEG >= radians) {
        break;
      }

      if (!reversed)
        Drive(DRIVE_KP * (pos - currLeft)
                  + vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL,
              DRIVE_KP * (pos * radiusRatio - currRight)
                  + vel * radiusRatio * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL);
      else
        Drive(- DRIVE_KP * (pos * radiusRatio + currLeft)
                  - vel * radiusRatio * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL,
              - DRIVE_KP * (pos + currRight)
                  -vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL);

      mogoPID();
      fourPID();
      currentTimer += tickSpeed; // wait until tickSpeed milliseconds have
                                 // passed since last iteration of while loop
      while (VexTimer < currentTimer) {
      }
    }
  } else if (radians < GyroAbsPos() / RAD_TO_DEG) {
    while (vel >= 0) {

      angleLeft = GyroAbsPos() / RAD_TO_DEG - radians;
      currLeft = (leftDrive.position(turns) - LeftPosStart) *
                 LargeOmni_Circumfrence * ENC_TO_DRIVE_WHEEL;
      currRight = (rightDrive.position(turns) - RightPosStart) *
                  LargeOmni_Circumfrence *
                  ENC_TO_DRIVE_WHEEL; /// this converts the code into inches
      if (stopDist(vel, accel) >= angleLeft * outerRadius) {
        vel -= accel / ticksPerSec; // decell
      } else if (vel < maxVel) {
        vel += accel / ticksPerSec;
      } else {
        vel = maxVel;
      }
      pos += vel / ticksPerSec;

      if (GyroAbsPos() / RAD_TO_DEG <= radians) {
        break;
      }
      if (!reversed)
        Drive(DRIVE_KP * (pos * radiusRatio - currLeft)
                  + vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL,
              DRIVE_KP * (pos - currRight)
                  + vel * radiusRatio * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL);
      else
        Drive(- DRIVE_KP * (pos + currLeft)
                  - vel * LargeOmni_InPerSec_TO_RPM / ENC_TO_DRIVE_WHEEL,
              - DRIVE_KP * (pos * radiusRatio + currRight)
                  - vel * radiusRatio * LargeOmni_Circumfrence / ENC_TO_DRIVE_WHEEL);
      GraphDebuggerVars(vel, stopDist(vel, accel), angleLeft * outerRadius, -GyroAbsPos(), -radians * RAD_TO_DEG);
      mogoPID();
      fourPID();
      currentTimer += tickSpeed; // wait until tickSpeed milliseconds have
                                 // passed since last iteration of while loop
      while (VexTimer < currentTimer) {
      }
    }
  }
  Drive(0, 0);
  currentHeading = radians * RAD_TO_DEG;
}

void mogoPID() {
  SoleMogo.spin(forward, (mogoTarg - MogoPot.angle(degrees))*MOGO_KP, rpm);
}
void fourPID() {
  

  plat2.spin(reverse, (fourTarg - LiftPot.angle(degrees))*FOUR_KP, rpm);
  plat1.spin(reverse, (fourTarg - LiftPot.angle(degrees))*FOUR_KP, rpm);
  
}

//graph variables on the brain screen. Call in a while loop.
//each iteration draws 1 pixel per color, up to 6 colors. No numeric values graphed
//good for comparing several different values as they change over time
int xcursor = 0;
void GraphDebuggerVars(int Red, int Blue, int Green, int Purple, int Orange, int Yellow)
{
  Brain.Screen.setPenColor(red);
  Brain.Screen.drawPixel(xcursor, Red);
  Brain.Screen.setPenColor(blue);
  Brain.Screen.drawPixel(xcursor, Blue);
  Brain.Screen.setPenColor(green);
  Brain.Screen.drawPixel(xcursor, Green);
  Brain.Screen.setPenColor(purple);
  Brain.Screen.drawPixel(xcursor, Purple);
  Brain.Screen.setPenColor(orange);
  Brain.Screen.drawPixel(xcursor, Orange);
  Brain.Screen.setPenColor(yellow);
  Brain.Screen.drawPixel(xcursor, Yellow);
  xcursor ++; //auto increment x cursor.
}
void AutonMogo(int pos, int duration)
{
  mogoTarg = pos; //set mogoTarg
  for(int i = 0; i < duration / FiftiethSecondTick; i ++)
      {
        mogoPID(); //while the duration hasn't been reached, call mogoPID and wait
        wait(FiftiethSecondTick, msec);
      }
}
void AutonLift(int pos, int duration)
{
  fourTarg = pos; //set mogoTarg
  for(int i = 0; i < duration / FiftiethSecondTick; i ++)
      {
        fourPID(); //while the duration hasn't been reached, call mogoPID and wait
        wait(FiftiethSecondTick, msec);
      }
}